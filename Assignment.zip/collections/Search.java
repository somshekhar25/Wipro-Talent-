
import java.util.ArrayList;
import java.util.List;

public class Search{
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("red");
        list.add("green");
        list.add("Orange");
        list.add("White");
        list.add("Black");
    System.out.println(list);
    System.out.println("the element at 2nd index: "+list.get(2));
    }
}