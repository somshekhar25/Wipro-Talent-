

import java.util.*;
class GetPropertiesDemo {
    public static void main (String [] args) {
        Properties x = System. getProperties () ;
        x. list (System.out);

    }
}