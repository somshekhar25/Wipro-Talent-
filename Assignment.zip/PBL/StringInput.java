// package PBL;

import java.util.Scanner;

public class StringInput {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        String A= sc.next();
        String B= sc.next();
        System.out.println(A+" Technologies "+B);
        sc.close();
    }

}