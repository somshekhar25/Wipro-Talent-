// package PBL;  <-- comment this out
import java.util.Scanner;

public class DynamicSum {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        int A= sc.nextInt();
        int B= sc.nextInt();
        System.out.println("The sum of "+A+" and "+B+" is= "+(A+B));
        sc.close();
    }
}
