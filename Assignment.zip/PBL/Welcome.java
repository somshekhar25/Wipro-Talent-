// public package PBL;

import java.util.Scanner;

public class Welcome {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        String A= sc.next();
        System.out.println("Welcome dear "+A);
        sc.close();
    }
} 
    

