package day1;

import java.util.*;

public class UserIdGeneration {
    public static String generateUserId(String firstName, String lastName, String pin, int n) {
        String smallerName, longerName;

        // Step 1: Decide smaller and longer name
        if (firstName.length() < lastName.length()) {
            smallerName = firstName;
            longerName = lastName;
        } else if (lastName.length() < firstName.length()) {
            smallerName = lastName;
            longerName = firstName;
        } else {
            // If lengths are equal → alphabetical order
            if (firstName.compareToIgnoreCase(lastName) < 0) {
                smallerName = firstName;
                longerName = lastName;
            } else {
                smallerName = lastName;
                longerName = firstName;
            }
        }

        // Step 2: Build user id
        char lastCharSmaller = smallerName.charAt(smallerName.length() - 1);
        char digitFromLeft = pin.charAt(n - 1); // 1-based index
        char digitFromRight = pin.charAt(pin.length() - n);

        String userId = "" + lastCharSmaller + longerName + digitFromLeft + digitFromRight;

        // Step 3: Toggle case
        StringBuilder toggled = new StringBuilder();
        for (char ch : userId.toCharArray()) {
            if (Character.isUpperCase(ch)) {
                toggled.append(Character.toLowerCase(ch));
            } else if (Character.isLowerCase(ch)) {
                toggled.append(Character.toUpperCase(ch));
            } else {
                toggled.append(ch);
            }
        }
        return toggled.toString();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String firstName = sc.next();
        String lastName = sc.next();
        String pin = sc.next();
        int n = sc.nextInt();
        sc.close();

        String userId = generateUserId(firstName, lastName, pin, n);
        System.out.println("Generated User ID: " + userId);
    }
}
