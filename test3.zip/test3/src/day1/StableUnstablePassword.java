package day1;

import java.util.*;

public class StableUnstablePassword {
    
    // Function to check if a number is stable
    public static boolean isStable(int num) {
        String s = String.valueOf(num);
        Map<Character, Integer> freq = new HashMap<>();

        for (char c : s.toCharArray()) {
            freq.put(c, freq.getOrDefault(c, 0) + 1);
        }

        int val = -1;
        for (int f : freq.values()) {
            if (val == -1) {
                val = f;
            } else if (val != f) {
                return false;
            }
        }
        return true;
    }

    // Function to calculate password
    public static int findPassword(int[] arr) {
        int sum = 0;
        for (int num : arr) {
            if (isStable(num)) {
                sum += num;
            }
        }
        return sum;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int[] arr = new int[5];

        System.out.println("Enter 5 numbers:");
        for (int i = 0; i < 5; i++) {
            arr[i] = sc.nextInt();
        }
        sc.close();

        int password = findPassword(arr);
        System.out.println("Password (sum of stable numbers) = " + password);
    }
}
