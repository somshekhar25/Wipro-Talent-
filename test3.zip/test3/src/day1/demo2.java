package day1;

public class demo2 {

	public static void main(String[] args) {
		int x=10;
		int y=5;
		System.out.println(++x+(++y));

	}

}
