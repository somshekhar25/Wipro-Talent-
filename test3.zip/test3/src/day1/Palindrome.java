package day1;

import java.util.HashMap;

public class Palindrome {

    public static void main(String[] args) {
        String input = "Template";
        int result = charactersToRemoveForPalindrome(input);
        System.out.println("Characters to remove: " + result);
    }

    public static int charactersToRemoveForPalindrome(String input1) {
        input1 = input1.toLowerCase();  // Case insensitive
        HashMap<Character, Integer> freqMap = new HashMap<>();

        // Count frequency of each character
        for (char ch : input1.toCharArray()) {
            freqMap.put(ch, freqMap.getOrDefault(ch, 0) + 1);
        }

        int oddCount = 0;
        for (int count : freqMap.values()) {
            if (count % 2 != 0) {
                oddCount++;
            }
        }

        // Case 1: all characters unique, cannot form a palindrome
        if (oddCount == input1.length()) {
            return -1;
        }

        // Case 2: already a palindrome (all even counts or one odd count allowed)
        if (oddCount <= 1) {
            return 0;
        }

        // Case 3: remove oddCount - 1 characters to make palindrome possible
        return oddCount - 1;
    }
}
