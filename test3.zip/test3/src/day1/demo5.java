package day1;

public class demo5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	        int number = -7; // Change this value as needed

	        if (number > 0) {
	            System.out.println("The number is positive.");
	        } else if (number < 0) {
	            System.out.println("The number is negative.");
	        } else {
	            System.out.println("The number is zero.");
	        }

	}

}
