package day1;

public class demo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean a=true;
		boolean b=false;
		
		int x=7;
		int y=9;
		int z=x^y;
		System.out.println("a&&b="+(a&&b));
		System.out.println("a||b="+(a||b));
		System.out.println("!(a&&b)="+!(a&&b));
		System.out.println("z="+z);
		
		
		
	}

}
